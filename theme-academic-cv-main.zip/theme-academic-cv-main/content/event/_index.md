---
title: Recent & Upcoming Talks
cms_exclude: true
#url: talk

# View
view: card

# Optional cover image (relative to `assets/media/` folder).
image:
  caption: ''
  filename: ''
---
